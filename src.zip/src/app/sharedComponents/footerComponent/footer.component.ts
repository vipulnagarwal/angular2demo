import {Component} from '@angular/core';

@Component({
  selector: 'navigation',
  styleUrls: ['./nav.component.css'],
  templateUrl: './nav.component.html'
})
export class NavigationComponent {
}
