import {Component} from '@angular/core';

@Component({
  selector: 'full-header',
  styleUrls: ['./header.component.css'],
  templateUrl: './header.component.html'
})
export class FullHeaderComponent {
}
