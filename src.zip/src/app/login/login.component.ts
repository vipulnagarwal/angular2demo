import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  isError:boolean = true;
  constructor(private formBuilder: FormBuilder,private router: Router) {}

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required],
    });
  }
  login(u:string,p:string): void {
    debugger;
    if(u && p){
      console.log(u);
      console.log(p);
      this.router.navigateByUrl('/home');
    }else{
      this.isError = false;
      return
    }

    
  }
}